<?php include('../includes/header.php'); ?>
<?php
// Sambungkan ke database
include('../includes/config.php');

// Ambil ID produk dari parameter URL
$id = $_GET['id'] ?? null;

// Validasi ID
if (!$id) {
    echo "Produk tidak ditemukan.";
    exit;
}

// Ambil data produk dari database berdasarkan ID
$query = "SELECT * FROM products WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

// Validasi jika produk tidak ditemukan
if (!$product) {
    echo "Produk tidak ditemukan.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <div class="container">
        <div class="product-detail">
            <!-- Gambar Produk -->
            <img src="../uploads/<?= htmlspecialchars($product['image']); ?>" alt="<?= htmlspecialchars($product['name']); ?>">

            <!-- Deskripsi Produk dan Tombol Add to Cart -->
            <div class="product-info">
                <h2><?= htmlspecialchars($product['name']); ?></h2>
                <p><?= htmlspecialchars($product['description']); ?></p>
                <span class="price">Rp <?= number_format($product['price'], 0, ',', '.'); ?></span>

                <!-- Form untuk menambahkan produk ke keranjang -->
                <form method="POST" action="add_to_cart.php">
                    <input type="hidden" name="id" value="<?= htmlspecialchars($product['id']); ?>"> <!-- ID Produk -->
                    <input type="hidden" name="name" value="<?= htmlspecialchars($product['name']); ?>"> <!-- Nama Produk -->
                    <input type="hidden" name="price" value="<?= htmlspecialchars($product['price']); ?>"> <!-- Harga Produk -->
                    <input type="hidden" name="image" value="<?= htmlspecialchars($product['image']); ?>"> <!-- Gambar Produk -->
                    <input type="hidden" name="quantity" value="1"> <!-- Jumlah produk, default 1 -->

                    <!-- Cek apakah customer sudah login -->
                    <?php if (isset($_SESSION['customer_id'])): ?>
                        <input type="hidden" name="customer_id" value="<?= $_SESSION['customer_id']; ?>"> <!-- ID Customer dari session -->
                        <button type="submit" name="add_to_cart">Add to Cart</button>
                    <?php else: ?>
                        <!-- Jika belum login, arahkan ke halaman login dengan redirect ke halaman produk -->
                        <button type="button" onclick="window.location.href='login_customers.php?redirect=<?= urlencode('product_details.php?id=' . $id); ?>'"> Add to Cart</button>
                    <?php endif; ?>
                </form>

            </div>
        </div>
    </div>

    <?php include('../includes/footer.php'); ?>
</body>

</html>