<!-- cart.php -->
<?php
session_start();
include('../includes/config.php');

// Pastikan customer sudah login
if (!isset($_SESSION['customer_id'])) {
    header("Location: login_customers.php");
    exit;
}

$customer_id = $_SESSION['customer_id'];

// Ambil data produk yang ada di cart
$query = "SELECT * FROM cart WHERE customer_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$cart_items = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <h2>Your Cart</h2>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total = 0;
            while ($item = $cart_items->fetch_assoc()) {
                $total += $item['price'] * $item['quantity'];
                echo "<tr>
                    <td>" . htmlspecialchars($item['product_name']) . "</td>
                    <td>$" . number_format($item['price'], 2) . "</td>
                    <td>" . $item['quantity'] . "</td>
                    <td>$" . number_format($item['price'] * $item['quantity'], 2) . "</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
    <h3>Total: $<?= number_format($total, 2); ?></h3>
    <a href="checkout.php">Proceed to Checkout</a>
</body>

</html>