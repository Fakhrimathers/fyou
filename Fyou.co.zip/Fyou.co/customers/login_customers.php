<!-- login_customers.php -->
<?php
session_start();
include('../includes/config.php');

// Jika customer sudah login, arahkan ke halaman produk atau cart
if (isset($_SESSION['customer_id'])) {
    header("Location: product_details.php");
    exit;
}

$error = '';

// Proses login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Cek apakah email ada di database
    $query = "SELECT * FROM customers WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $customer = $result->fetch_assoc();

        // Verifikasi password
        if (password_verify($password, $customer['password'])) {
            $_SESSION['customer_id'] = $customer['id'];
            $_SESSION['email'] = $customer['email'];
            header("Location: product_details.php"); // Redirect ke halaman produk setelah login berhasil
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Email tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Customer</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="login-page">
    <div class="login-container">
        <h2>Login Customer</h2>
        <?php if ($error) {
            echo "<p>$error</p>";
        } ?>
        <form method="POST" action="login_customers.php">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>Belum punya akun? <a href="register_customers.php">Daftar</a></p>
    </div>
</body>

</html>