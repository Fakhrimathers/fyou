<!-- register_customers.php -->
<?php
include('../includes/config.php');

// Jika customer sudah login, arahkan ke halaman produk atau cart
if (isset($_SESSION['customer_id'])) {
    header("Location: product_details.php");
    exit;
}

$error = '';

// Proses pendaftaran customer
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validasi data
    if (empty($name) || empty($email) || empty($password)) {
        $error = "Semua kolom harus diisi!";
    } else {
        // Cek apakah email sudah ada
        $query = "SELECT * FROM customers WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email sudah terdaftar!";
        } else {
            // Hash password sebelum disimpan
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Masukkan data customer ke database
            $query = "INSERT INTO customers (name, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sss", $name, $email, $hashed_password);

            if ($stmt->execute()) {
                header("Location: login_customers.php"); // Redirect ke halaman login setelah sukses
                exit;
            } else {
                $error = "Terjadi kesalahan saat mendaftar!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Customer</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="register-page">
    <div class="register-container">
        <h2>Register Customer</h2>
        <?php if ($error) {
            echo "<p>$error</p>";
        } ?>
        <form method="POST" action="register_customers.php">
            <input type="text" name="name" placeholder="Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Register</button>
        </form>
        <p>Sudah punya akun? <a href="login_customers.php">Login</a></p>
    </div>
</body>

</html>