<?php
include('../includes/config.php');

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cek apakah tombol Add to Cart ditekan
if (isset($_POST['add_to_cart'])) {
    // Ambil data dari form
    $product_id = $_POST['id']; // ID produk yang dikirimkan dari halaman product_detail.php
    $product_name = $_POST['name']; // Nama produk
    $price = $_POST['price']; // Harga produk
    $quantity = $_POST['quantity']; // Jumlah yang dipilih
    $image = $_POST['image']; // Gambar produk
    $customer_id = $_POST['customer_id']; // ID pelanggan (misalnya dari session)

    // Validasi input data
    if (empty($product_id) || empty($product_name) || empty($price) || empty($quantity) || empty($customer_id)) {
        echo "Error: Data incomplete!";
        exit;
    }

    // Cek apakah produk tersedia di database berdasarkan product_id
    $query = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Pastikan produk ditemukan
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();

        // Insert produk ke keranjang
        $query = "INSERT INTO cart (customer_id, product_id, product_name, price, quantity, image) 
                  VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("iisis", $customer_id, $product_id, $product_name, $price, $quantity, $image);

        // Redirect ke halaman cart setelah berhasil
        header("Location: cart.php");
        exit;
    } else {
        echo "Error: Could not add product to cart!";
    }
} else {
    // Produk tidak ditemukan di database
    echo "Produk tidak ditemukan di database!";
}
