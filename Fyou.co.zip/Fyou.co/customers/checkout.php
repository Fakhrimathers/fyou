<?php
session_start();
include('../includes/config.php');

// Cek apakah customer sudah login
if (!isset($_SESSION['customer_id'])) {
    // Jika belum login, arahkan ke halaman login
    header("Location: login_customer.php");
    exit;
}

// Ambil data pelanggan dari session
$customer_id = $_SESSION['customer_id'];

// Ambil data cart yang dimiliki customer
$query = "SELECT * FROM cart WHERE customer_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $customer_id);
$stmt->execute();
$result = $stmt->get_result();
$cart_items = $result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <div class="container">
        <h2>Checkout</h2>
        <form action="process_checkout.php" method="POST">
            <!-- Tampilkan data cart -->
            <?php foreach ($cart_items as $item): ?>
                <div class="cart-item">
                    <img src="../uploads/<?= $item['image']; ?>" alt="<?= $item['product_name']; ?>">
                    <p><?= $item['product_name']; ?> - <?= $item['quantity']; ?> x Rp <?= number_format($item['price'], 0, ',', '.'); ?></p>
                </div>
            <?php endforeach; ?>

            <!-- Data Pengiriman -->
            <label for="address">Address</label>
            <input type="text" name="address" required>

            <label for="phone">Phone</label>
            <input type="text" name="phone" required>

            <button type="submit">Proceed to Payment</button>
        </form>
    </div>
</body>

</html>