<?php include('../includes/header.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop All</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <!-- Shop All Title -->
    <section class="shop-all-title">
        <h2>SHOP ALL</h2>
    </section>

    <!-- Product Section -->
    <section class="product-section">
        <?php
        // Koneksi ke database
        include('../includes/config.php');

        // Cek kategori dari URL, default ke 'all'
        $category = isset($_GET['category']) ? $_GET['category'] : 'all';

        // Query untuk mengambil data produk
        $sql = ($category === 'all')
            ? "SELECT * FROM products"
            : "SELECT * FROM products WHERE category = '$category'";

        $result = mysqli_query($conn, $sql);

        // Jika query berhasil
        if (mysqli_num_rows($result) > 0) {
            while ($product = mysqli_fetch_assoc($result)) {
                echo '
                <div class="product">
                    <a href="product_details.php?id=' . $product['id'] . '">
                        <img src="../uploads/' . $product['image'] . '" alt="' . $product['name'] . '">
                    </a>
                    <h3><a href="product_details.php?id=' . $product['id'] . '">' . $product['name'] . '</a></h3>
                    <span>  Rp ' . $product['price'] . '</span>
                </div>
                ';
            }
        } else {
            echo '<p>No products found for this category.</p>';
        }
        ?>
    </section>

    <?php include('../includes/footer.php'); ?>

</body>

</html>