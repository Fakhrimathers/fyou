<!-- Footer php -->
<!-- Footer Section -->
<footer style="background-color: #000; color: #fff; padding: 40px 0;">
    <div class="footer-container" style="display: flex; justify-content: space-between; align-items: flex-start; padding: 0 20px;">

        <!-- Our Mission Section -->
        <div class="footer-section" style="width: 45%;">
            <h3>OUR MISSION</h3>
            <p>Fakhri uses second-hand clothing as a form of self-expression to project his inner personality outward, boosting confidence. Fakhri strives to curate the best one-of-a-kind, hand-picked collection of vintage clothing. Each individual piece is chosen by Fakhri, and I hope you love it as much as I do.</p>
        </div>

        <!-- Shipping & Returns Section -->
        <div class="footer-section" style="width: 45%;">
            <h3>SHIPPING & RETURNS</h3>
            <p>Free shipping on all INDONESIA orders.</p>
            <p>Our curation includes second hand clothing and may contain distressing and other signs of wear. Please look at the pictures carefully before purchasing.</p>
            <p>ALL SALES FINAL. NO RETURNS.</p>
        </div>
    </div>

    <!-- Subscribe and Social Media Links -->
    <div class="subscribe-social" style="display: flex; justify-content: space-between; align-items: center; padding: 20px 20px 10px 20px;">

        <!-- Subscribe Button -->
        <div class="subscribe" style="width: 45%;">
            <button style="background-color: #fff; color: #000; border: none; padding: 10px 20px; font-size: 16px; cursor: pointer;">Subscribe to Our Emails</button>
        </div>

        <!-- Social Media Icons -->
        <div class="social-icons" style="width: 45%; text-align: right;">
            <a href="#" style="margin: 0 10px;">
                <img src="img/instagram.jpg" alt="Instagram" style="width: 30px; height: 30px;">
            </a>
            <a href="#" style="margin: 0 10px;">
                <img src="img/grail.png" alt="Grailed" style="width: 30px; height: 30px;">
            </a>
            <a href="#" style="margin: 0 10px;">
                <img src="img/tiktok.jpg" alt="TikTok" style="width: 30px; height: 30px;">
            </a>
            <a href="#" style="margin: 0 10px;">
                <img src="img/discord.jpg" alt="YouTube" style="width: 30px; height: 30px;">
            </a>
        </div>
    </div>

    <!-- Copyright Section -->
    <div class="copyright" style="text-align: center; padding: 10px; font-size: 12px;">
        <p>&copy; 2024 Fyou.co. All Rights Reserved.</p>
    </div>
</footer>
</footer>