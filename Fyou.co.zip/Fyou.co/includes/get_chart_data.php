<?php
// Menghubungkan ke database
include '../includes/config.php';

// Ambil data produk
$query = "SELECT name, stock FROM products";
$result = mysqli_query($conn, $query);

// Siapkan data untuk dikirim dalam format JSON
$data = [];
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
}

// Header untuk JSON
header('Content-Type: application/json');
echo json_encode($data, JSON_PRETTY_PRINT);
