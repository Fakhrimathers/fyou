<!-- header.php -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fyou.co</title>
    <link rel="stylesheet" href="../css/style.css">

</head>

<body>
    <!-- Header Section -->
    <header>
        <div class="title">Fyou.co</div>
        <div class="header-icons">
            <a href="#"><img src="img/bag.jpg" alt="Shop"></a>
            <a href="#"><img src="img/user.jpg" alt="Log In/Sign"></a>
            <a href="#"><img src="img/search.jpg" alt="Search"></a>
        </div>
    </header>

    <!-- Navigation Menu -->
    <nav class="main-menu">
        <ul>
            <li><a href="/fyou.co/index.php">Home</a></li> <!-- Absolute path ke root -->
            <li><a href="/fyou.co/customers/shop_all.php?category=all">Shop All</a></li>
            <li><a href="/fyou.co/customers/shop_all.php?category=pants">Pants</a></li>
            <li><a href="/fyou.co/customers/shop_all.php?category=tees">Tees</a></li>
            <li><a href="/fyou.co/customers/shop_all.php?category=hoodie">Hoodie</a></li>
            <li><a href="/fyou.co/customers/shop_all.php?category=outer">Outer</a></li>
            <li><a href="#">Seasonal Collection</a></li>
            <li><a href="/fyou.co/customers/contact.php">Contact</a></li> <!-- Absolute path ke root -->
        </ul>
    </nav>