<link rel="stylesheet" href="../css/style.css">
<?php
session_start(); // Memulai session

// Cek apakah admin sudah login
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit;
}

include('../includes/config.php'); // Menghubungkan dengan database

// Cek apakah ada ID produk
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mengambil data produk berdasarkan ID
    $query = "SELECT * FROM products WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    // Cek apakah produk ditemukan
    if (mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
    } else {
        echo "Product not found!";
        exit;
    }
}

// Cek apakah form sudah disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];
    $category = $_POST['category'];

    // Update data produk
    $updateQuery = "UPDATE products SET name = '$name', price = '$price', stock = '$stock', description = '$description', category = '$category' WHERE id = '$id'";

    if (mysqli_query($conn, $updateQuery)) {
        echo "Product updated successfully!";
        header("Location: admin_dashboard.php"); // Arahkan kembali ke dashboard admin
        exit;
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<form method="POST" action="">
    <input type="text" name="name" value="<?php echo $product['name']; ?>" required>
    <input type="text" name="price" value="<?php echo $product['price']; ?>" required>
    <input type="number" name="stock" value="<?php echo $product['stock']; ?>" required>
    <textarea name="description"><?php echo $product['description']; ?></textarea>
    <select name="category">
        <option value="pants" <?php if ($product['category'] == 'pants') echo 'selected'; ?>>Pants</option>
        <option value="tees" <?php if ($product['category'] == 'tees') echo 'selected'; ?>>Tees</option>
        <option value="outer" <?php if ($product['category'] == 'outer') echo 'selected'; ?>>Outer</option>
    </select>
    <button type="submit">Update Product</button>
</form>