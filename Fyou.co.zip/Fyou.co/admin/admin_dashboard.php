<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Link ke Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>

<body class="admin-dashboard">
    <?php
    // Memulai session
    session_start();

    // Cek apakah admin sudah login
    if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
        header("Location: login.php"); // Jika tidak login, arahkan ke halaman login
        exit;
    }

    // Menghubungkan dengan database
    include('../includes/config.php');

    echo "<h2></h2>";

    // Container untuk grafik
    echo "
    <div class='chart-container' style='width: 80%; margin: auto; padding-top: 20px;'>
        <h3></h3>
        <canvas id='stockChart'></canvas>
    </div>";

    // Query untuk mengambil nama, stock, dan kategori produk
    $query = "SELECT name, stock, category FROM products";
    $result = mysqli_query($conn, $query);

    // Siapkan data untuk chart
    $categories = [];
    $stocks = [];

    while ($product = mysqli_fetch_assoc($result)) {
        $categories[] = $product['category'];
        $stocks[] = $product['stock'];
    }

    // Encode data dalam format JSON untuk digunakan di chart
    $data = json_encode(['categories' => $categories, 'stocks' => $stocks]);
    ?>

    <script>
        // Ambil data dari PHP
        var chartData = <?php echo $data; ?>;

        // Buat grafik Chart.js
        var ctx = document.getElementById('stockChart').getContext('2d');
        var stockChart = new Chart(ctx, {
            type: 'bar', // Tipe grafik
            data: {
                labels: chartData.categories, // Kategori produk
                datasets: [{
                    label: 'Stock Produk',
                    data: chartData.stocks, // Data stock produk
                    backgroundColor: 'rgba(75, 192, 192, 0.2)', // Warna background bar
                    borderColor: 'rgba(75, 192, 192, 1)', // Warna border bar
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true // Y-axis mulai dari 0
                    }
                }
            }
        });
    </script>

    <?php
    // Query untuk mengambil seluruh data produk
    $query = "SELECT * FROM products";
    $result = mysqli_query($conn, $query);

    // Cek apakah ada produk di database
    if (mysqli_num_rows($result) > 0) {
        echo "<table class='admin-table'>
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Description</th>
                <th>Category</th>
                <th>Actions</th>
            </tr>";

        // Menampilkan produk
        while ($product = mysqli_fetch_assoc($result)) {
            echo "<tr>
                <td>" . $product['name'] . "</td>
                <td>" . $product['price'] . "</td>
                <td>" . $product['stock'] . "</td>
                <td>" . $product['description'] . "</td>
                <td>" . $product['category'] . "</td>
                <td>
                    <a href='update_product.php?id=" . $product['id'] . "' class='button update-btn'>Update</a> 
                    <a href='delete_product.php?id=" . $product['id'] . "' class='button delete-btn'>Delete</a>
                </td>
            </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No products found.</p>";
    }

    // Link untuk menambah produk
    echo "<br><a href='add_product.php' class='button add-btn'>Add New Product</a>";
    // Tombol Log Out
    echo "<a href='logout.php' class='logout-btn'>Log Out</a>";
    ?>
    <!-- Link atau tombol untuk menuju ke halaman Messages -->
    <a href="message.php" class="btn">View Messages</a>
</body>

<!-- Link ke script.js -->
<script src="../js/script.js"></script>

</html>