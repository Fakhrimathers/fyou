<?php
session_start();
include('../includes/config.php');

// Cek apakah admin sudah login
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit();
}

// Cek jika ada ID produk yang diberikan
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];
    $query = "DELETE FROM products WHERE id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $product_id);

    if (mysqli_stmt_execute($stmt)) {
        header("Location: admin_dashboard.php");
        exit();
    } else {
        echo "Error deleting product.";
    }
} else {
    echo "Product ID is required.";
}
