<?php
include('../includes/config.php');

if (isset($_POST['message_id'])) {
    $message_id = $_POST['message_id'];

    // Query untuk menghapus pesan
    $query = "DELETE FROM contact_messages WHERE id = $message_id";

    if ($conn->query($query) === TRUE) {
        // Jika berhasil menghapus, alihkan kembali ke halaman messages
        header('Location: message.php');
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}
