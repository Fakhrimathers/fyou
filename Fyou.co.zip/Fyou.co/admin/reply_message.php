<?php
include('../includes/config.php');

// Pastikan ID pesan ada
if (isset($_POST['message_id'])) {
    $message_id = $_POST['message_id'];

    // Ambil data pesan berdasarkan ID
    $query = "SELECT * FROM contact_messages WHERE id = $message_id";
    $result = $conn->query($query);
    $message = $result->fetch_assoc();

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reply_message'])) {
        $reply = $_POST['reply_message'];

        // Kirim balasan lewat email atau simpan ke database (tergantung implementasi balasan)
        // Sebagai contoh, kita simpan ke database
        $reply_query = "INSERT INTO replies (message_id, reply) VALUES ($message_id, '$reply')";
        if ($conn->query($reply_query) === TRUE) {
            echo "Reply sent successfully!";
        } else {
            echo "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply Message</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body>
    <div class="container">
        <h2>Reply to Message</h2>

        <!-- Form untuk balas pesan -->
        <form action="reply_message.php" method="POST">
            <input type="hidden" name="message_id" value="<?= $message['id']; ?>">
            <textarea name="reply_message" rows="6" required placeholder="Your reply here..."></textarea>
            <button type="submit" class="btn reply-btn">Send Reply</button>
        </form>

        <hr>
        <p><strong>Original Message:</strong></p>
        <p><strong>Name:</strong> <?= htmlspecialchars($message['name']); ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($message['email']); ?></p>
        <p><strong>Message:</strong><br> <?= nl2br(htmlspecialchars($message['message'])); ?></p>
    </div>
</body>

</html>