<?php
session_start();

// Cek apakah admin sudah login
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("Location: login.php");
    exit;
}

// Koneksi ke database
include('../includes/config.php');

// Variabel status sukses atau gagal
$statusMessage = "";

if (isset($_POST['submit'])) {
    // Ambil data dari form
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $description = $_POST['description'];
    $category = $_POST['category'];  // Ambil kategori dari form
    $image = $_FILES['image']['name'];

    // Mengupload file gambar
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($image);
    move_uploaded_file($_FILES['image']['tmp_name'], $target_file);

    // Insert data produk ke database termasuk kategori
    $query = "INSERT INTO products (name, price, stock, description, image, category) 
              VALUES ('$name', '$price', '$stock', '$description', '$image', '$category')"; // Menambahkan kategori ke query

    if (mysqli_query($conn, $query)) {
        // Jika sukses, tampilkan pesan sukses
        $statusMessage = "Produk berhasil ditambahkan!";
    } else {
        // Jika gagal, tampilkan pesan error
        $statusMessage = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="../css/style.css">
</head>

<body class="add-product-page" id="add-product">

    <h2>Tambah Produk Baru</h2>

    <!-- Pesan status -->
    <?php if ($statusMessage != "") {
        echo "<p>$statusMessage</p>";
    } ?>

    <!-- Form untuk input produk -->
    <form action="add_product.php" method="POST" enctype="multipart/form-data">
        <label for="name">Nama Produk:</label><br>
        <input type="text" id="name" name="name" required><br><br>

        <label for="price">Harga:</label><br>
        <input type="number" id="price" name="price" step="0.01" required><br><br>

        <label for="stock">Stok:</label><br>
        <input type="number" id="stock" name="stock" required><br><br>

        <label for="description">Deskripsi:</label><br>
        <textarea id="description" name="description" rows="4" cols="50" required></textarea><br><br>

        <label for="image">Gambar Produk:</label><br>
        <input type="file" id="image" name="image" required><br><br>

        <!-- Field untuk memilih kategori -->
        <label for="category">Kategori:</label><br>
        <select id="category" name="category" required>
            <option value="pants">Pants</option>
            <option value="tees">Tees</option>
            <option value="outer">Outer</option>
            <option value="hoodie">Hoodie</option>
        </select><br><br>

        <button type="submit" name="submit">Tambah Produk</button>
    </form>
</body>

</html>