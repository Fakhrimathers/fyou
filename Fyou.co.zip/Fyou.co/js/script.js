// Bagian Hero Slider tetap sama
let currentSlide = 0;
const slides = document.querySelectorAll('.hero-slider .slide');
const totalSlides = slides.length;

const nextButton = document.querySelector('.hero-slider .next');
const prevButton = document.querySelector('.hero-slider .prev');

function changeSlide() {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + 1) % totalSlides;
    slides[currentSlide].classList.add('active');
}

function prevSlide() {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
    slides[currentSlide].classList.add('active');
}

setInterval(changeSlide, 5000);
nextButton?.addEventListener('click', changeSlide);
prevButton?.addEventListener('click', prevSlide);
slides[currentSlide]?.classList.add('active');

// Bagian untuk memuat data grafik dan menggambar grafik
const ctx = document.getElementById('stockChart').getContext('2d');
fetch('../get_chart_data.php')
    .then((response) => response.json())
    .then((data) => {
        const labels = data.map((item) => item.name); // Ambil nama produk
        const stockData = data.map((item) => item.stock); // Ambil jumlah stok

        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Jumlah Stok Produk',
                        data: stockData,
                        backgroundColor: 'rgba(54, 162, 235, 0.5)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                    },
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Jumlah Stok',
                        },
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Nama Produk',
                        },
                    },
                },
            },
        });
    })
    .catch((error) => console.error('Error fetching chart data:', error));
document.addEventListener('DOMContentLoaded', function () {
    // Pastikan DOM sudah siap
    console.log('Admin Dashboard Script Loaded');
    let slideIndex = 0;
    const slides = document.querySelectorAll('.carousel-item');
    const totalSlides = slides.length;

    function moveSlide(step) {
        slideIndex += step;

        // Mengatur agar slideIndex tetap dalam batas yang valid
        if (slideIndex < 0) {
            slideIndex = totalSlides - 1; // Jika slideIndex kurang dari 0, kembali ke slide terakhir
        }
        if (slideIndex >= totalSlides) {
            slideIndex = 0; // Jika slideIndex lebih dari totalSlides, kembali ke slide pertama
        }

        updateCarousel();
    }

    function updateCarousel() {
        const carousel = document.querySelector('.carousel');
        carousel.style.transform = `translateX(-${slideIndex * 100}%)`;

        // Update indikator jika ada
        updateIndicators();
    }

    // Mengupdate indikator (untuk menunjukkan slide aktif, jika diperlukan)
    function updateIndicators() {
        const indicators = document.querySelectorAll('.carousel-indicators button');
        indicators.forEach((indicator, index) => {
            if (index === slideIndex) {
                indicator.classList.add('active');
            } else {
                indicator.classList.remove('active');
            }
        });
    }

    // Fungsi interval otomatis untuk mengganti slide setiap 10 detik
    setInterval(() => {
        moveSlide(1);
    }, 10000); // 10000 ms = 10 detik
});
